/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_1;

import java.awt.Rectangle;
import java.util.Random;

/**
 *
 * @author usci
 */
public class IntersectionPrinter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random generator = new Random();
        Rectangle r1 = new Rectangle(generator.nextInt(51),generator.nextInt(51),generator.nextInt(51),generator.nextInt(51));
        Rectangle r2 = new Rectangle(generator.nextInt(51),generator.nextInt(51),generator.nextInt(51),generator.nextInt(51));
        Rectangle r3 = r1.intersection(r2);
        
        System.out.println(r1);
        System.out.println(r2);
        System.out.println("Is the intersected rectangle emply?:" + r3.isEmpty());
    }
    
}
